# CatCore =^.^=

Boots real Windows 10 / 11 from a normal Android app. No root, no dual boot, no bootloader unlock.
CatCore Boot (a coreboot-style stage runner) prepares the virtual PC, then QEMU runs it inside the app
and a built-in VNC viewer shows the screen. It is emulated (no KVM without root), so expect slow speed.

## Before you build, add three things
1. **QEMU engine**: an arm64 Android build of `qemu-system-x86_64` saved as
   `app/src/main/jniLibs/arm64-v8a/libqemu-system-x86_64.so` (static, or with its libraries next to it).
2. **UEFI firmware**: `OVMF_CODE.fd` and `OVMF_VARS.fd` in `app/src/main/assets/firmware/`
   (Debian/Ubuntu `ovmf` package, folder `/usr/share/OVMF/`; rename the files if they have a `_4M` suffix).
3. **Windows ISOs**: use the Get ISO button in the app (opens Microsoft's official download page), then Import ISO.
   Tiny10 / Tiny11 builds run much faster than stock Windows.

## Build
Push to GitHub. Actions builds the APK (Actions tab, artifact `CatCore-debug-apk`).

## Using it
1. Import the ISO, press Boot. When you see "Press any key to boot from CD", tap Enter.
2. Install Windows. When setup is finished, switch off "Boot from the installer ISO" so it boots from the disk.
3. Windows 11 says "This PC can't run Windows 11": press Shift+F10 in setup, run `regedit`, create
   `HKLM\SYSTEM\Setup\LabConfig` with DWORD values `BypassTPMCheck`, `BypassSecureBootCheck`, `BypassRAMCheck` = 1.
4. Touch: tap = left click, long press = right click, drag = move the pointer.
