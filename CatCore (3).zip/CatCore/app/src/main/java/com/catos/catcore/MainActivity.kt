package com.catos.catcore

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

val Plum = Color(0xFF1A1022)
val Panel = Color(0xFF2A1838)
val Pink = Color(0xFFFF5FA2)
val Violet = Color(0xFFB794FF)
val Soft = Color(0xFFF3E8FF)

class MainActivity : ComponentActivity() {
    private lateinit var boot: CatCoreBoot

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        boot = CatCoreBoot(applicationContext)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Pink, secondary = Violet, background = Plum,
                    surface = Panel, onSurface = Soft, onBackground = Soft, onPrimary = Plum,
                )
            ) {
                Surface(Modifier.fillMaxSize(), color = Plum) {
                    CatCoreApp(boot) { on ->
                        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) boot.halt()
    }
}

@Composable
fun CatCoreApp(boot: CatCoreBoot, keepAwake: (Boolean) -> Unit) {
    var vnc by remember { mutableStateOf<VncClient?>(null) }
    val scope = rememberCoroutineScope()
    val client = vnc
    if (client == null) {
        BootMenu(boot) {
            val c = VncClient()
            c.start(scope)
            vnc = c
            keepAwake(true)
        }
    } else {
        Display(client) { client.stop(); boot.halt(); vnc = null; keepAwake(false) }
    }
}

@Composable
fun BootMenu(boot: CatCoreBoot, onUp: () -> Unit) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }
    var tick by remember { mutableStateOf(0) }
    var ram by remember { mutableStateOf(boot.ramMb.toFloat()) }
    var cores by remember { mutableStateOf(boot.cores.toFloat()) }
    var disk by remember { mutableStateOf(boot.diskGb.toFloat()) }

    Column(
        Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("CatCore", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Pink)
        Text("=^.^=  boot manager by Ahmed", color = Violet)
        if (note.isNotEmpty()) Text(note, color = Pink)

        ENTRIES.forEach { e ->
            EntryCard(boot, e, tick, busy, { note = it }, { tick++ }) {
                busy = true
                scope.launch {
                    val ok = boot.boot(e)
                    busy = false
                    if (ok) onUp()
                }
            }
        }

        Knob("Guest RAM", "${ram.toInt()} MB", ram, 1024f..6144f) { ram = it; boot.ramMb = it.toInt() / 256 * 256 }
        Knob("CPU cores", "${cores.toInt()}", cores, 1f..8f) { cores = it; boot.cores = it.toInt() }
        Knob("New disk size", "${disk.toInt()} GB", disk, 16f..128f) { disk = it; boot.diskGb = it.toInt() }

        BootLog(boot, Modifier.fillMaxWidth().height(200.dp))
    }
}

@Composable
fun EntryCard(
    boot: CatCoreBoot, e: BootEntry, tick: Int, busy: Boolean,
    setNote: (String) -> Unit, onImported: () -> Unit, onBoot: () -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val has = remember(tick) { boot.iso(e).exists() }
    var attach by remember { mutableStateOf(boot.attachIso(e)) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            boot.importIso(uri, e) { setNote("Importing ${e.title}: $it%") }
            setNote("")
            onImported()
        }
    }
    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(e.title, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = Soft)
            Text(if (has) "ISO ready" else "No ISO yet. Download one from Microsoft, then import it.", color = Violet)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(e.url))) }) { Text("Get ISO") }
                OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Import ISO") }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = attach, onCheckedChange = { attach = it; boot.setAttachIso(e, it) })
                Spacer(Modifier.width(8.dp))
                Text("Boot from the installer ISO", color = Soft)
            }
            Button(enabled = !busy && (has || !attach), onClick = onBoot) { Text("Boot ${e.title}") }
        }
    }
}

@Composable
fun Knob(label: String, value: String, v: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column {
        Text("$label: $value", color = Soft)
        Slider(value = v, onValueChange = onChange, valueRange = range)
    }
}

@Composable
fun BootLog(boot: CatCoreBoot, modifier: Modifier) {
    val lines by boot.log.collectAsState()
    val st = rememberLazyListState()
    LaunchedEffect(lines.size) { if (lines.isNotEmpty()) st.animateScrollToItem(lines.lastIndex) }
    LazyColumn(modifier.background(Color.Black, RoundedCornerShape(8.dp)).padding(8.dp), state = st) {
        items(lines) { Text(it, color = Color(0xFFFFB3D9), fontFamily = FontFamily.Monospace, fontSize = 11.sp) }
    }
}

private fun VncClient.touch(o: Offset, box: IntSize, mask: Int, click: Boolean) {
    val bm = bitmap ?: return
    val s = minOf(box.width.toFloat() / bm.width, box.height.toFloat() / bm.height)
    val x = ((o.x - (box.width - bm.width * s) / 2) / s).toInt().coerceIn(0, bm.width - 1)
    val y = ((o.y - (box.height - bm.height * s) / 2) / s).toInt().coerceIn(0, bm.height - 1)
    pointer(x, y, 0)
    if (click) { pointer(x, y, mask); pointer(x, y, 0) }
}

@Composable
fun Display(vnc: VncClient, onStop: () -> Unit) {
    val frame by vnc.frame.collectAsState()
    val status by vnc.status.collectAsState()
    var text by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        Box(Modifier.weight(1f).fillMaxWidth().background(Color.Black)) {
            Canvas(
                Modifier.fillMaxSize()
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onTap = { vnc.touch(it, size, 1, true) },
                            onLongPress = { vnc.touch(it, size, 4, true) },
                        )
                    }
                    .pointerInput(Unit) {
                        detectDragGestures { change, _ -> vnc.touch(change.position, size, 0, false) }
                    }
            ) {
                if (frame < 0) return@Canvas
                val bm = vnc.bitmap ?: return@Canvas
                val s = minOf(size.width / bm.width, size.height / bm.height)
                val w = bm.width * s
                val h = bm.height * s
                val l = (size.width - w) / 2
                val t = (size.height - h) / 2
                drawIntoCanvas { it.nativeCanvas.drawBitmap(bm, null, android.graphics.RectF(l, t, l + w, t + h), null) }
            }
            if (status != "live") Text(status, color = Pink, modifier = Modifier.align(Alignment.Center))
        }
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            KeyBtn("Enter") { vnc.tap(0xFF0D) }
            KeyBtn("Esc") { vnc.tap(0xFF1B) }
            KeyBtn("Tab") { vnc.tap(0xFF09) }
            KeyBtn("Backspace") { vnc.tap(0xFF08) }
            KeyBtn("Win") { vnc.tap(0xFFEB) }
            KeyBtn("Ctrl+Alt+Del") { vnc.ctrlAltDel() }
            Button(onClick = onStop) { Text("Power off", fontSize = 12.sp) }
        }
        Row(Modifier.padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = text, onValueChange = { text = it }, modifier = Modifier.weight(1f),
                singleLine = true, placeholder = { Text("Type into Windows") },
            )
            Spacer(Modifier.width(6.dp))
            Button(onClick = { vnc.type(text); text = "" }) { Text("Send") }
        }
    }
}

@Composable
fun KeyBtn(label: String, onClick: () -> Unit) =
    OutlinedButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 10.dp)) { Text(label, fontSize = 12.sp) }
