package com.catos.catcore

import android.graphics.Bitmap
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import java.io.*
import java.net.Socket
import java.nio.ByteBuffer
import java.nio.ByteOrder

private fun b(vararg v: Int) = ByteArray(v.size) { v[it].toByte() }

/** Minimal RFB (VNC) client: raw encoding only, which is plenty over loopback. */
class VncClient {
    @Volatile var bitmap: Bitmap? = null
    val frame = MutableStateFlow(0)
    val status = MutableStateFlow("Starting the virtual PC...")
    private val outbox = Channel<ByteArray>(Channel.UNLIMITED)
    @Volatile private var socket: Socket? = null

    fun start(scope: CoroutineScope): Job = scope.launch(Dispatchers.IO) {
        try {
            val s = Socket("127.0.0.1", 5900).also { socket = it }
            val inp = DataInputStream(BufferedInputStream(s.getInputStream(), 1 shl 16))
            val out = DataOutputStream(BufferedOutputStream(s.getOutputStream()))
            fun skip(n: Int) { if (n > 0) inp.readFully(ByteArray(n)) }

            inp.readFully(ByteArray(12))                       // server version
            out.write("RFB 003.008\n".toByteArray()); out.flush()
            skip(inp.readUnsignedByte())                       // security types
            out.writeByte(1); out.flush()                      // choose "None"
            if (inp.readInt() != 0) throw IOException("VNC security failed")
            out.writeByte(1); out.flush()                      // shared session
            val w = inp.readUnsignedShort(); val h = inp.readUnsignedShort()
            skip(16); skip(inp.readInt())                      // pixel format + name
            resize(w, h)

            // 32bpp little-endian true colour (B,G,R,X), raw + desktop-size encodings
            out.write(b(0,0,0,0, 32,24,0,1, 0,255, 0,255, 0,255, 16,8,0, 0,0,0))
            out.write(b(2,0,0,2, 0,0,0,0, 0xFF,0xFF,0xFF,0x21))
            out.write(req(0, w, h)); out.flush()

            launch { for (m in outbox) { out.write(m); out.flush() } }

            while (isActive) {
                when (inp.readUnsignedByte()) {
                    0 -> {
                        inp.readUnsignedByte()
                        repeat(inp.readUnsignedShort()) {
                            val x = inp.readUnsignedShort(); val y = inp.readUnsignedShort()
                            val rw = inp.readUnsignedShort(); val rh = inp.readUnsignedShort()
                            when (val enc = inp.readInt()) {
                                0 -> readRaw(inp, x, y, rw, rh)
                                -223 -> resize(rw, rh)
                                else -> throw IOException("unsupported encoding $enc")
                            }
                        }
                        frame.update { it + 1 }
                        status.value = "live"
                        bitmap?.let { outbox.trySend(req(1, it.width, it.height)) }
                    }
                    2 -> {}                                    // bell
                    3 -> { skip(3); skip(inp.readInt()) }      // clipboard text
                    else -> throw IOException("unexpected server message")
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            status.value = "Disconnected: ${e.message}"
        } finally {
            stop()
        }
    }

    private fun req(inc: Int, w: Int, h: Int) = b(3, inc, 0,0, 0,0, w shr 8, w and 255, h shr 8, h and 255)

    private fun resize(w: Int, h: Int) { bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888) }

    private fun readRaw(inp: DataInputStream, x: Int, y: Int, w: Int, h: Int) {
        val bytes = ByteArray(w * h * 4).also { inp.readFully(it) }
        val px = IntArray(w * h)
        ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asIntBuffer().get(px)
        for (i in px.indices) px[i] = px[i] or (0xFF shl 24)
        bitmap?.setPixels(px, 0, w, x, y, w, h)
    }

    fun stop() { runCatching { socket?.close() }; outbox.close() }

    fun pointer(x: Int, y: Int, buttons: Int) {
        outbox.trySend(b(5, buttons, x shr 8, x and 255, y shr 8, y and 255))
    }

    fun key(sym: Int, down: Boolean) {
        outbox.trySend(b(4, if (down) 1 else 0, 0, 0, sym ushr 24, (sym shr 16) and 255, (sym shr 8) and 255, sym and 255))
    }

    fun tap(sym: Int) { key(sym, true); key(sym, false) }
    fun type(text: String) = text.forEach { tap(it.code) }

    fun ctrlAltDel() {
        listOf(0xFFE3, 0xFFE9, 0xFFFF).forEach { key(it, true) }
        listOf(0xFFFF, 0xFFE9, 0xFFE3).forEach { key(it, false) }
    }
}
