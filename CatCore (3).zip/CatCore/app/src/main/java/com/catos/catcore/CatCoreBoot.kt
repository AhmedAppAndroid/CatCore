package com.catos.catcore

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile
import java.net.Socket

data class BootEntry(val id: String, val title: String, val isoName: String, val url: String)

val ENTRIES = listOf(
    BootEntry("win11", "Windows 11", "win11.iso", "https://www.microsoft.com/software-download/windows11"),
    BootEntry("win10", "Windows 10", "win10.iso", "https://www.microsoft.com/software-download/windows10ISO"),
)

/**
 * CatCore Boot: a small coreboot-style firmware layer.
 * romstage (engine check) -> ramstage (memory + disk) -> firmware (UEFI) -> payload (Windows).
 */
class CatCoreBoot(private val ctx: Context) {
    val log = MutableStateFlow(listOf("=^.^= CatCore Boot v0.1 ready"))
    private var proc: Process? = null
    private val prefs = ctx.getSharedPreferences("catcore", Context.MODE_PRIVATE)

    private fun say(s: String) = log.update { (it + s).takeLast(400) }

    private val libDir get() = ctx.applicationInfo.nativeLibraryDir
    private val qemuBin get() = File(libDir, "libqemu-system-x86_64.so")
    fun iso(e: BootEntry) = File(ctx.filesDir, "iso/${e.isoName}")
    private fun vmDir(e: BootEntry) = File(ctx.filesDir, "vm/${e.id}").apply { mkdirs() }

    private fun recommendedRam(): Int {
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return ((mi.totalMem / 1048576).toInt() / 3 / 256 * 256).coerceIn(1024, 4096)
    }

    var ramMb: Int
        get() = prefs.getInt("ram", recommendedRam())
        set(v) { prefs.edit().putInt("ram", v).apply() }
    var cores: Int
        get() = prefs.getInt("cores", minOf(4, Runtime.getRuntime().availableProcessors()))
        set(v) { prefs.edit().putInt("cores", v).apply() }
    var diskGb: Int
        get() = prefs.getInt("disk", 32)
        set(v) { prefs.edit().putInt("disk", v).apply() }
    fun attachIso(e: BootEntry) = prefs.getBoolean("iso_${e.id}", true)
    fun setAttachIso(e: BootEntry, v: Boolean) = prefs.edit().putBoolean("iso_${e.id}", v).apply()

    /** QEMU cannot read content:// URIs, so the ISO is copied into app storage. */
    suspend fun importIso(uri: Uri, e: BootEntry, onProgress: (Int) -> Unit) = withContext(Dispatchers.IO) {
        val dst = iso(e).apply { parentFile!!.mkdirs() }
        val total = ctx.contentResolver.openFileDescriptor(uri, "r")?.use { it.statSize } ?: -1L
        ctx.contentResolver.openInputStream(uri)!!.use { i ->
            dst.outputStream().use { o ->
                val buf = ByteArray(1 shl 20)
                var done = 0L
                var n: Int
                while (i.read(buf).also { n = it } > 0) {
                    o.write(buf, 0, n)
                    done += n
                    if (total > 0) onProgress((done * 100 / total).toInt())
                }
            }
        }
        say("ISO imported for ${e.title}: ${dst.length() / 1048576} MB")
    }

    /** Runs all boot stages. Returns true once QEMU is up and its display port is open. */
    suspend fun boot(e: BootEntry): Boolean = withContext(Dispatchers.IO) {
        say("== romstage ==")
        if (!qemuBin.exists()) {
            say("FATAL: ${qemuBin.name} is missing. Put it in app/src/main/jniLibs/arm64-v8a/ and rebuild.")
            return@withContext false
        }
        say("engine: ${qemuBin.name} found")

        say("== ramstage ==")
        say("guest RAM $ramMb MB, $cores cores")
        val dir = vmDir(e)
        val disk = File(dir, "disk.img")
        if (!disk.exists()) {
            say("creating $diskGb GB sparse disk")
            RandomAccessFile(disk, "rw").use { it.setLength(diskGb * 1024L * 1024L * 1024L) }
        }

        say("== firmware ==")
        val code = File(dir, "OVMF_CODE.fd")
        val vars = File(dir, "OVMF_VARS.fd")
        try {
            if (!code.exists()) ctx.assets.open("firmware/OVMF_CODE.fd").use { i -> code.outputStream().use { i.copyTo(it) } }
            if (!vars.exists()) ctx.assets.open("firmware/OVMF_VARS.fd").use { i -> vars.outputStream().use { i.copyTo(it) } }
        } catch (ex: Exception) {
            say("FATAL: UEFI firmware missing. Put OVMF_CODE.fd and OVMF_VARS.fd in app/src/main/assets/firmware/")
            return@withContext false
        }
        say("UEFI firmware loaded")

        val useIso = attachIso(e)
        if (useIso && !iso(e).exists()) {
            say("FATAL: no ISO for ${e.title}. Tap Import ISO first.")
            return@withContext false
        }

        say("== payload: ${e.title} ==")
        val a = mutableListOf(
            qemuBin.absolutePath,
            "-machine", "q35", "-cpu", "max", "-accel", "tcg,thread=multi", // static engine has no ROM folder, so no option ROMs
            "-smp", "$cores", "-m", "$ramMb",
            "-drive", "if=pflash,format=raw,unit=0,readonly=on,file=${code.absolutePath}",
            "-drive", "if=pflash,format=raw,unit=1,file=${vars.absolutePath}",
            "-drive", "if=none,id=hd0,format=raw,file=${disk.absolutePath}",
            "-device", "nvme,drive=hd0,serial=catcore0,bootindex=2",
            "-device", "qemu-xhci", "-device", "usb-tablet", "-device", "usb-kbd",
            "-nodefaults", "-device", "VGA,romfile=",
            "-netdev", "user,id=n0", "-device", "e1000e,netdev=n0,romfile=",
            "-rtc", "base=localtime",
            "-display", "none", "-vnc", "127.0.0.1:0",
        )
        if (useIso) a += listOf(
            "-drive", "if=none,id=cd0,media=cdrom,readonly=on,format=raw,file=${iso(e).absolutePath}",
            "-device", "ich9-ahci,id=ahci", "-device", "ide-cd,drive=cd0,bus=ahci.0,bootindex=1",
        )

        val pb = ProcessBuilder(a).redirectErrorStream(true).directory(dir)
        pb.environment()["LD_LIBRARY_PATH"] = libDir
        val p = try { pb.start() } catch (ex: Exception) { say("FATAL: cannot start engine: ${ex.message}"); return@withContext false }
        proc = p
        Thread {
            p.inputStream.bufferedReader().forEachLine { say("qemu: $it") }
            say("engine stopped (exit ${runCatching { p.exitValue() }.getOrNull()})")
        }.start()

        repeat(60) {
            if (!p.isAlive) return@withContext false
            try { Socket("127.0.0.1", 5900).close(); say("display online"); return@withContext true } catch (_: Exception) {}
            delay(500)
        }
        say("FATAL: display did not come up")
        halt()
        false
    }

    fun halt() { proc?.destroy(); proc = null }
}
