# CatCore =^.^=

Boots real Windows 10 / 11 from a normal Android app. No root, no dual boot, no bootloader unlock.
CatCore Boot (a coreboot-style stage runner) prepares the virtual PC, then QEMU runs it inside the app
and a built-in VNC viewer shows the screen. It is emulated (no KVM without root), so expect slow speed.

## Build (all automatic)
Push to GitHub. The workflow `.github/workflows/build.yml` does everything:
1. **engine job** (arm64 runner, free for public repositories): builds a static `qemu-system-x86_64` with Alpine,
   renames it `libqemu-system-x86_64.so`, and smoke-tests it with the same command line the app uses.
   First run is slow; the result is cached. Change `ENGINE_REV` in the workflow to force a rebuild.
2. **apk job**: adds the engine and the OVMF UEFI firmware, builds `CatCore-debug.apk`.

Download the APK from Actions > the run > Artifacts. If the engine job fails, the run log shows why;
the APK job still builds, but the app will say the engine is missing.

**Windows ISOs**: use Get ISO in the app (opens Microsoft's official download page), then Import ISO.
Tiny10 / Tiny11 builds run much faster than stock Windows.

## Using it
1. Import the ISO, press Boot. When you see "Press any key to boot from CD", tap Enter.
2. Install Windows. When setup is finished, switch off "Boot from the installer ISO" so it boots from the disk.
3. Windows 11 says "This PC can't run Windows 11": press Shift+F10 in setup, run `regedit`, create
   `HKLM\SYSTEM\Setup\LabConfig` with DWORD values `BypassTPMCheck`, `BypassSecureBootCheck`, `BypassRAMCheck` = 1.
4. Touch: tap = left click, long press = right click, drag = move the pointer.

## GitHub Actions notes
- Tag a version (`v0.1`) and the APK is also attached to a GitHub Release.
- From a phone: GitHub web > Add file > Create new file, type `.github/workflows/build.yml` as the name, paste the workflow.
- If websites do not load inside Windows, set the DNS server to 8.8.8.8 in the network adapter settings
  (Android gives QEMU no resolv.conf to copy from).
