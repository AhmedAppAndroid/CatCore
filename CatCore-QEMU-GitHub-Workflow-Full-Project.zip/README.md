# CatCore — Android ARM64 QEMU packaging build

This project retains the CatCore UI, custom icon, local VNC viewer, and QEMU launcher.
Unlike the original icon-only APK, this **source build attempts to bundle QEMU** and
its native dependencies and UEFI firmware, downloaded at **build time**. The
result does **not** require the Termux app on the phone.

## Status: Android runtime NOT verified

The script and workflow have been prepared, but QEMU binaries cannot be downloaded
and Android cannot be executed in this editing environment. A successfully built
APK is not proof that Windows boots. Test the device and inspect the boot log.
Do not present this as a verified, working Windows-on-Android APK yet.

### Requirements

- A phone with a **64-bit ARM Android OS (arm64-v8a)**, enough RAM/storage to
  create a Windows VM, and a legally obtained Windows ISO. A 32-bit Android OS
  cannot load this ARM64 engine, even if the processor supports ARM64.
- GitHub Actions access, to build on Ubuntu with an Android SDK and internet.
- Windows is **not included**, and the user must provide installation media.
- Running x86 Windows using QEMU TCG on ARM is likely **very slow**.

### Build

1. Upload **the contents** of this source ZIP to the **root** of a GitHub repository.
   `settings.gradle.kts` and `.github/workflows/build.yml` must be at the repo root.
2. Open GitHub **Actions → Build CatCore with QEMU engine (ARM64) → Run workflow**
   (or push to `main`).
3. Wait for the workflow outcome. If it passes, download artifact
   `CatCore-ARM64-QEMU-debug-apk` from that workflow run.
4. Install only after checking Play Protect's warning/scan; **keep Play Protect ON**.
   A debug APK may still be labelled unknown/unrecognized. Do not bypass a harmful
   app warning. To support reliable updates, sign future builds with a permanent
   private signing key; this workflow intentionally emits a debug-signed build.
5. Import a Windows ISO through CatCore's UI, then select Boot.

### How the integrated runtime works

`tools/bundle_qemu.py` fetches Termux ARM64 package metadata and package files
from the official Termux repository over HTTPS, verifies all package SHA-256
hashes in the index, and extracts:

- `libqemu-system-x86_64.so` (ARM64-built executable named for Android JNI packaging)
- its dependent Android/Bionic `.so` libraries, with DT_NEEDED/RPATH adjusted
- QEMU option ROMs and EDK2 UEFI code/variables as APK assets

QEMU executable and dependency files are packed in `jniLibs/arm64-v8a` so Android
extracts them to `nativeLibraryDir`. QEMU does not run from `/data/data/.../files`.
CatCore stages ROMs to private storage at runtime and starts the VM without
exposing an unauthenticated TCP VNC port (Unix domain socket only).

The workflow **fails** if a required engine/UEFI file is missing in the built APK.
This is a packaging check, **not** a successful on-device emulator test. Android
linker namespace, symbol resolution, OS policies, and QEMU runtime compatibility
may still require investigation.

### Security & licensing

Keep Google Play Protect enabled. Do not add root access, turn off Play Protect,
or use a bypass to install blocked applications. No malicious-app-free guarantee
is made. The APK is rebuilt and re-signed: the new signing identity might not
be compatible with your previous APK's update signature.

QEMU is licensed under GPL-2.0, and its dependencies and firmware have their own
license obligations. Review `THIRD_PARTY_NOTICES.txt`; before redistributing
compiled APKs, comply with corresponding source availability and notice terms.
QEMU upstream: https://www.qemu.org  · Termux packages:
https://github.com/termux/termux-packages
