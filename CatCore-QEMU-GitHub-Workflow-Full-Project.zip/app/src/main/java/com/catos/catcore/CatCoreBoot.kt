package com.catos.catcore

import android.app.ActivityManager
import android.content.Context
import android.net.LocalSocket
import android.net.LocalSocketAddress
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile

/** User-supplied Windows installation media is not bundled or downloaded by CatCore. */
data class BootEntry(val id: String, val title: String, val isoName: String, val url: String)

val ENTRIES = listOf(
    BootEntry("win11", "Windows 11", "win11.iso", "https://www.microsoft.com/software-download/windows11"),
    BootEntry("win10", "Windows 10", "win10.iso", "https://www.microsoft.com/software-download/windows10ISO"),
)

class CatCoreBoot(private val ctx: Context) {
    val log = MutableStateFlow(listOf("=^.^= CatCore ready"))
    private var proc: Process? = null
    private val prefs = ctx.getSharedPreferences("catcore", Context.MODE_PRIVATE)
    private fun say(message: String) { log.update { (it + message).takeLast(400) } }

    private val libDir get() = ctx.applicationInfo.nativeLibraryDir
    private val qemuBin get() = File(libDir, "libqemu-system-x86_64.so")
    private val vncSocketFile get() = File(ctx.cacheDir, "catcore-vnc.sock")
    val vncPath: String get() = vncSocketFile.absolutePath

    fun iso(e: BootEntry) = File(ctx.filesDir, "iso/${e.isoName}")
    private fun vmDir(e: BootEntry) = File(ctx.filesDir, "vm/${e.id}").apply { mkdirs() }

    /** Do not reserve more RAM than the Android host can realistically spare. */
    private fun recommendedRam(): Int {
        val info = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(info)
        return ((info.totalMem / 1048576L).toInt() / 3 / 256 * 256).coerceIn(512, 4096)
    }
    var ramMb: Int
        get() = prefs.getInt("ram", recommendedRam())
        set(v) { prefs.edit().putInt("ram", v).apply() }
    var cores: Int
        get() = prefs.getInt("cores", minOf(2, Runtime.getRuntime().availableProcessors()))
        set(v) { prefs.edit().putInt("cores", v).apply() }
    var diskGb: Int
        get() = prefs.getInt("disk", 32)
        set(v) { prefs.edit().putInt("disk", v).apply() }
    fun attachIso(e: BootEntry) = prefs.getBoolean("iso_${e.id}", true)
    fun setAttachIso(e: BootEntry, v: Boolean) = prefs.edit().putBoolean("iso_${e.id}", v).apply()

    suspend fun importIso(uri: Uri, e: BootEntry, onProgress: (Int) -> Unit) = withContext(Dispatchers.IO) {
        val dst = iso(e).apply { parentFile!!.mkdirs() }
        val temp = File(dst.parentFile, "${dst.name}.partial")
        try {
            val total = ctx.contentResolver.openFileDescriptor(uri, "r")?.use { it.statSize } ?: -1L
            ctx.contentResolver.openInputStream(uri)!!.use { input ->
                temp.outputStream().use { output ->
                    val buffer = ByteArray(1024 * 1024)
                    var done = 0L
                    while (true) {
                        val size = input.read(buffer)
                        if (size < 0) break
                        output.write(buffer, 0, size)
                        done += size
                        if (total > 0) onProgress((done * 100L / total).toInt().coerceIn(0, 100))
                    }
                }
            }
            if (!temp.renameTo(dst)) error("Cannot move imported ISO into place")
            say("Imported ${e.title} ISO: ${dst.length() / 1048576} MB")
        } finally { temp.delete() }
    }

    private fun assetToFile(name: String, dest: File) {
        if (dest.exists()) return
        val tmp = File(dest.parentFile, "${dest.name}.partial")
        try {
            ctx.assets.open("firmware/$name").use { input ->
                tmp.outputStream().use { output -> input.copyTo(output) }
            }
            check(tmp.renameTo(dest)) { "Could not stage $name" }
        } finally { tmp.delete() }
    }

    /** Stage QEMU option ROMs from the APK (QEMU's -L path must be a real directory). */
    private fun stageQemuRomDirectory(): File {
        val dst = File(ctx.noBackupFilesDir, "qemu-roms").apply { mkdirs() }
        fun copyTree(relative: String, output: File) {
            val children = ctx.assets.list("firmware/qemu/$relative") ?: emptyArray()
            if (children.isEmpty()) {
                if (relative.isNotEmpty()) assetToFile("qemu/$relative", output)
            } else {
                output.mkdirs()
                for (name in children) {
                    val next = if (relative.isEmpty()) name else "$relative/$name"
                    copyTree(next, File(output, name))
                }
            }
        }
        copyTree("", dst)
        require(File(dst, "bios.bin").isFile || File(dst, "bios-256k.bin").isFile) {
            "QEMU BIOS option ROMs are not packaged"
        }
        return dst
    }

    suspend fun boot(e: BootEntry): Boolean = withContext(Dispatchers.IO) {
        halt()
        say("== engine verification ==")
        if (!qemuBin.isFile) {
            say("ERROR: QEMU for Android ARM64 is not included in this APK.")
            say("Build requires jniLibs/arm64-v8a/libqemu-system-x86_64.so and all its linked libraries.")
            return@withContext false
        }
        if (!qemuBin.canExecute()) {
            say("ERROR: Android cannot execute the packaged QEMU engine")
            return@withContext false
        }
        val roms = try { stageQemuRomDirectory() } catch (ex: Exception) {
            say("ERROR: QEMU firmware ROMs are missing: ${ex.message}")
            return@withContext false
        }
        val directory = vmDir(e)
        val disk = File(directory, "disk.img")
        val code = File(directory, "OVMF_CODE.fd")
        val vars = File(directory, "OVMF_VARS.fd")
        try {
            assetToFile("OVMF_CODE.fd", code)
            assetToFile("OVMF_VARS.fd", vars)
        } catch (ex: Exception) {
            say("ERROR: UEFI firmware not included: ${ex.message}")
            return@withContext false
        }
        if (attachIso(e) && !iso(e).isFile) {
            say("ERROR: Import an official Windows ISO before booting")
            return@withContext false
        }
        if (!disk.exists()) {
            say("Creating ${diskGb} GB sparse virtual disk")
            try {
                RandomAccessFile(disk, "rw").use { it.setLength(diskGb.coerceIn(16, 128) * 1024L * 1024L * 1024L) }
            } catch (ex: Exception) {
                say("ERROR: Cannot create disk: ${ex.message}")
                return@withContext false
            }
        }
        // An app-private Unix-domain socket is safer than an unauthenticated TCP VNC port.
        vncSocketFile.delete()
        val args = mutableListOf(
            qemuBin.absolutePath,
            "-L", roms.absolutePath,
            "-machine", "q35", "-cpu", "max", "-accel", "tcg,thread=multi",
            "-smp", cores.coerceIn(1, 8).toString(), "-m", ramMb.coerceIn(512, 6144).toString(),
            "-drive", "if=pflash,format=raw,unit=0,readonly=on,file=${code.absolutePath}",
            "-drive", "if=pflash,format=raw,unit=1,file=${vars.absolutePath}",
            "-drive", "if=none,id=hd0,format=raw,file=${disk.absolutePath}",
            "-device", "nvme,drive=hd0,serial=catcore0,bootindex=2",
            "-device", "qemu-xhci", "-device", "usb-tablet", "-device", "usb-kbd",
            "-vga", "std", "-netdev", "user,id=n0", "-device", "e1000e,netdev=n0",
            "-rtc", "base=localtime", "-display", "none",
            "-vnc", "unix:${vncSocketFile.absolutePath}",
        )
        if (attachIso(e)) args += listOf(
            "-drive", "if=none,id=cd0,media=cdrom,readonly=on,format=raw,file=${iso(e).absolutePath}",
            "-device", "ich9-ahci,id=ahci", "-device", "ide-cd,drive=cd0,bus=ahci.0,bootindex=1",
        )
        val builder = ProcessBuilder(args).directory(directory).redirectErrorStream(true)
        builder.environment()["LD_LIBRARY_PATH"] = libDir
        builder.environment()["TMPDIR"] = ctx.cacheDir.absolutePath
        builder.environment()["HOME"] = ctx.filesDir.absolutePath
        builder.environment()["XDG_CONFIG_HOME"] = ctx.filesDir.absolutePath
        builder.environment()["XDG_CACHE_HOME"] = ctx.cacheDir.absolutePath
        builder.environment()["QEMU_MODULE_DIR"] = libDir
        say("Starting Windows VM (software emulation; performance may be slow)")
        val p = try { builder.start() } catch (ex: Exception) {
            say("ERROR: QEMU cannot start: ${ex.message}")
            return@withContext false
        }
        proc = p
        Thread {
            try { p.inputStream.bufferedReader().forEachLine { say("qemu: $it") } }
            catch (ex: Exception) { say("QEMU log reader: ${ex.message}") }
            say("QEMU stopped")
        }.apply { isDaemon = true; start() }
        repeat(80) {
            if (!p.isAlive) { say("ERROR: QEMU exited before its display was ready"); return@withContext false }
            try {
                LocalSocket().use { s ->
                    s.connect(LocalSocketAddress(vncPath, LocalSocketAddress.Namespace.FILESYSTEM))
                }
                say("Display ready")
                return@withContext true
            } catch (_: Exception) { /* display not ready */ }
            delay(500)
        }
        say("ERROR: Timed out waiting for the QEMU VNC display")
        halt()
        false
    }

    fun halt() {
        proc?.destroy()
        proc = null
        vncSocketFile.delete()
    }
}
