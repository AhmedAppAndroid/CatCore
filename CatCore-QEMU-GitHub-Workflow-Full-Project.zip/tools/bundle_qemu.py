#!/usr/bin/env python3
"""Bundle an Android/bionic ARM64 QEMU build from official Termux packages.

Build-time tool, intended for GitHub Actions Linux runners. It does not install
Termux on the user's device and does not modify the phone's security settings.

This is a packaging aid, not a guarantee that the resulting emulator boots on
all Android devices. Native runtime validation must be done on Android ARM64.
"""
import argparse
import hashlib
import lzma
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import time
from urllib.error import URLError
from urllib.parse import quote
from urllib.request import urlopen

REPO = 'https://packages.termux.dev/apt/termux-main'
INDEX = REPO + '/dists/stable/main/binary-aarch64/Packages.xz'
PREFIX = Path('data/data/com.termux/files/usr')
SYSTEM_SONAMES = {
    'libc.so', 'libdl.so', 'libm.so', 'liblog.so', 'libandroid.so',
    'libz.so', 'libstdc++.so', 'libEGL.so', 'libGLESv2.so',
    'libGLESv3.so', 'libOpenSLES.so', 'libvulkan.so',
}

def download(url: str) -> bytes:
    error = None
    for attempt in range(4):
        try:
            with urlopen(url, timeout=90) as response:
                return response.read()
        except (OSError, URLError) as ex:
            error = ex
            time.sleep(attempt + 1)
    raise RuntimeError(f'Unable to download {url}: {error}')

def parse_index(blob):
    # Debian control fields may have indented continuation lines.
    packages = {}
    provides = {}
    for paragraph in blob.decode('utf-8').split('\n\n'):
        field = {}
        last = None
        for line in paragraph.splitlines():
            if line.startswith(' ') and last:
                field[last] += ' ' + line.strip()
            elif ': ' in line:
                k, v = line.split(': ', 1)
                last = k
                field[k] = v.strip()
        if field.get('Package'):
            packages[field['Package']] = field
    for name, package in packages.items():
        for token in package.get('Provides', '').split(','):
            v = re.sub(r'\s*\(.*', '', token).strip()
            if v and v not in provides: provides[v] = name
    return packages, provides

def dependency_name(token, packages, provides):
    for alt in token.split('|'):
        name = re.split(r'[ (\[]', alt.strip(), maxsplit=1)[0]
        if name in packages: return name
        if name in provides: return provides[name]
    return None

def sh(*args):
    return subprocess.check_output(args, text=True, stderr=subprocess.STDOUT).strip()

def is_elf(file):
    if not file.is_file(): return False
    with file.open('rb') as f: return f.read(4) == b'\x7fELF'

def needed(file):
    result = sh('patchelf', '--print-needed', str(file))
    return [l.strip() for l in result.splitlines() if l.strip()]

def canonical(name):
    # Android's PackageManager only recognizes unversioned lib*.so entries.
    m = re.match(r'^(lib[^/]+?\.so)(?:\.[0-9].*)?$', name)
    return m.group(1) if m else None

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--project', type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    project = args.project.resolve()
    libs_dst = project/'app/src/main/jniLibs/arm64-v8a'
    fw_dst = project/'app/src/main/assets/firmware'
    libs_dst.mkdir(parents=True, exist_ok=True)
    fw_dst.mkdir(parents=True, exist_ok=True)
    for name in ('libqemu-system-x86_64.so',):
        (libs_dst/name).unlink(missing_ok=True)
    packages, provides = parse_index(lzma.decompress(download(INDEX)))
    print(f'Termux catalog: {len(packages)} ARM64 packages')
    queue = ['qemu-system-x86-64-headless', 'qemu-common', 'qemu-system-i386-headless']
    visited, selected = set(), []
    while queue:
        name = queue.pop(0)
        if name in visited: continue
        if name not in packages:
            raise RuntimeError(f'Missing required package {name}')
        visited.add(name)
        p = packages[name]
        selected.append(p)
        for token in p.get('Depends', '').split(','):
            if not token.strip(): continue
            dep = dependency_name(token, packages, provides)
            if dep and dep not in visited: queue.append(dep)
    print(f'Including {len(selected)} Termux packages (QEMU + transitive dependencies)')
    with tempfile.TemporaryDirectory(prefix='catcore-qemu-') as tmp:
        tmp = Path(tmp)
        extracted = tmp/'unpacked'
        extracted.mkdir()
        for num, entry in enumerate(selected, 1):
            path = entry['Filename'].lstrip('/')
            if not path.startswith('pool/'):
                raise RuntimeError('Unexpected repository package path: '+path)
            filename = tmp/f'{num:03d}.deb'
            payload = download(REPO+'/'+quote(path, safe='/'))
            want_sha = entry.get('SHA256')
            if not want_sha or hashlib.sha256(payload).hexdigest().lower() != want_sha.lower():
                raise RuntimeError(f'Failed package integrity check: {entry["Package"]}')
            filename.write_bytes(payload)
            subprocess.run(['dpkg-deb', '-x', str(filename), str(extracted)], check=True)
            filename.unlink()
            print(f'[{num}/{len(selected)}] {entry["Package"]} {len(payload)//1024}KiB', flush=True)
        pfx = extracted/PREFIX
        qemu_paths = [pfx/'bin/qemu-system-x86_64', pfx/'bin/qemu-system-i386']
        binary = next((p for p in qemu_paths if is_elf(p)), None)
        if binary is None:
            raise RuntimeError('Neither qemu-system-x86_64 nor qemu-system-i386 executable found')
        if binary.name != 'qemu-system-x86_64':
            raise RuntimeError('QEMU x86_64 engine not found; refusing to package a different guest CPU')
        source_libs = pfx/'lib'
        if not source_libs.exists(): raise RuntimeError('QEMU dependency library directory not present')
        copies = {canonical(p.name): p for p in source_libs.rglob('*') if p.is_file() and is_elf(p) and canonical(p.name)}
        if len(copies) < 5: raise RuntimeError('Too few libraries extracted to run QEMU')
        dest_bin = libs_dst/'libqemu-system-x86_64.so'
        shutil.copy2(binary, dest_bin)
        for name, source in sorted(copies.items()):
            if name in SYSTEM_SONAMES: continue  # prefer Android platform builtins
            shutil.copy2(source, libs_dst/name)
        # Relocate libraries and normalize versioned SONAMEs; Termux builds use
        # /data/data/com.termux/files/usr/lib (not accessible in another app).
        all_elfs = [dest_bin] + sorted(p for p in libs_dst.glob('lib*.so') if p != dest_bin)
        aliases = {}
        for elf in all_elfs:
            for name in needed(elf):
                short = canonical(name)
                if short and short != name and (libs_dst/short).is_file():
                    aliases[name] = short
        for elf in all_elfs:
            subprocess.run(['patchelf', '--remove-rpath', str(elf)], check=True)
            for old in needed(elf):
                if old in aliases:
                    subprocess.run(['patchelf', '--replace-needed', old, aliases[old], str(elf)], check=True)
            if elf != dest_bin:
                subprocess.run(['patchelf', '--set-soname', elf.name, str(elf)], check=True)
        # Important: blindly copying native files is not enough. Refuse broken packages.
        missing = {need for elf in all_elfs for need in needed(elf)
                   if need not in SYSTEM_SONAMES and not (libs_dst/need).is_file()}
        if missing:
            raise RuntimeError('Unresolved ELF shared libraries: '+', '.join(sorted(missing)))
        try:
            interpreter = sh('patchelf', '--print-interpreter', str(dest_bin))
        except subprocess.CalledProcessError as e:
            raise RuntimeError(f'Not an executable ELF: {e}') from e
        if interpreter != '/system/bin/linker64':
            raise RuntimeError(f'QEMU Android linker expected; found {interpreter}')
        if 'AArch64' not in sh('readelf', '-h', str(dest_bin)):
            raise RuntimeError('QEMU is not ARM64')
        # qemu-common contains SeaBIOS, OVMF and VGA option ROMs.
        shared = pfx/'share/qemu'
        if not shared.is_dir(): raise RuntimeError('qemu-common ROMs missing')
        code = shared/'edk2-x86_64-code.fd'
        vars = shared/'edk2-i386-vars.fd'
        if not code.is_file() or not vars.is_file():
            raise RuntimeError('qemu-common must contain edk2-x86_64-code.fd and edk2-i386-vars.fd')
        for target, source in [('OVMF_CODE.fd', code), ('OVMF_VARS.fd', vars)]:
            shutil.copy2(source, fw_dst/target)
        shutil.copytree(shared, fw_dst/'qemu', dirs_exist_ok=True)
        # Source/provenance manifest; licenses and upstream links in README.
        (project/'QEMU_PACKAGE_MANIFEST.txt').write_text('\n'.join(
            f'{p["Package"]} {p.get("Version", "?")} {p.get("SHA256", "?")} {p["Filename"]}'
            for p in selected) + '\n')
        print('Bundled QEMU:', dest_bin.stat().st_size, 'bytes')
        print('Libraries:', len(all_elfs), 'UEFI firmware present; no missing DT_NEEDED')
        print('Android runtime execution still requires testing on real hardware.')

if __name__ == '__main__':
    main()
